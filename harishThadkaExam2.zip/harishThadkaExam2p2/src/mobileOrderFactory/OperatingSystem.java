/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mobileOrderFactory;

/**
 * This is a operating system interface
 * @author Harish Thadka
 */
public interface OperatingSystem {
    
    /**
     * Getter method for operating system of apple in string
     * @return OS version of Apple
     */
    String getOperatingSystem();
}
