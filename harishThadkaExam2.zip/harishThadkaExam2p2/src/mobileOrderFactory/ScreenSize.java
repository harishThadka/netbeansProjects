/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mobileOrderFactory;

/**
 *
 * @author Harish Thadka
 */
public interface ScreenSize {

    /**
     *
     * @param size size
     */
    void setScreensize(double size);

    /**
     *
     * @return Screen size of mobile
     */
    double getScreenSize();
}
