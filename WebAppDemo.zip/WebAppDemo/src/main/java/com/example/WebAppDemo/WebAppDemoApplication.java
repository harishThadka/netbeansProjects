package com.example.WebAppDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebAppDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebAppDemoApplication.class, args);
	}

}
